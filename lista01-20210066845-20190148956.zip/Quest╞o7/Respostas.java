public class Respostas{
    public String sexo;
    public String resposta;
}