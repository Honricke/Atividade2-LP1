public class Alunos {
    public String sexo;
    public int vezesVtbl;
}
