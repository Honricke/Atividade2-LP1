public class Alturas{
    public String sexo;
    public int altura;
}